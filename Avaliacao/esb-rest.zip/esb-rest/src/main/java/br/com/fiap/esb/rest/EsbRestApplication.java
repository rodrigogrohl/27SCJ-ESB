package br.com.fiap.esb.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsbRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(EsbRestApplication.class, args);
	}
}
